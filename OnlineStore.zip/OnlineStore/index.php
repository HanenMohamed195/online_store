<?php include 'includes/header.php'; ?>

<div class="container">
    <h1 class="page-title">🛍️ Welcome to Our Store</h1>
    
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?php 
            echo $_SESSION['message']; 
            unset($_SESSION['message']);
            ?>
        </div>
    <?php endif; ?>
    
    <!-- Categories Filter -->
    <div style="text-align: center; margin-bottom: 30px;">
        <a href="index.php" class="btn btn-primary" style="margin: 5px;">All Products</a>
        <?php
        $cat_result = mysqli_query($conn, "SELECT * FROM Category");
        while ($cat = mysqli_fetch_assoc($cat_result)):
        ?>
        <a href="index.php?category=<?php echo $cat['CategoryID']; ?>" class="btn btn-info" style="margin: 5px;">
            <?php echo htmlspecialchars($cat['Name']); ?>
        </a>
        <?php endwhile; ?>
    </div>
    
    <div class="products-grid">
        <?php
        $category_filter = "";
        if (isset($_GET['category'])) {
            $category_id = (int)$_GET['category'];
            $category_filter = "WHERE p.CategoryID = $category_id";
        }
        
        $sql = "SELECT p.*, c.Name as CategoryName 
                FROM Product p 
                JOIN Category c ON p.CategoryID = c.CategoryID 
                $category_filter
                ORDER BY p.ProductID DESC";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0):
            while ($product = mysqli_fetch_assoc($result)):
                $stock_class = $product['StockQuantity'] < 20 ? 'low' : '';
                
                // Icons based on category
                $icons = [
                    'Electronics' => '💻',
                    'Clothing' => '👕',
                    'Books' => '📚'
                ];
                $icon = $icons[$product['CategoryName']] ?? '📦';
        ?>
        <div class="product-card">
            <div class="product-image">
                <?php echo $icon; ?>
            </div>
            <div class="product-info">
                <h3 class="product-name"><?php echo htmlspecialchars($product['Name']); ?></h3>
                <p class="product-category">📁 <?php echo htmlspecialchars($product['CategoryName']); ?></p>
                <p class="product-description">
                    <?php echo htmlspecialchars(substr($product['Description'], 0, 60)) . '...'; ?>
                </p>
                <p class="product-price">$<?php echo number_format($product['Price'], 2); ?></p>
                <p class="product-stock <?php echo $stock_class; ?>">
                    📦 <?php echo $product['StockQuantity']; ?> in stock
                </p>
                
                <?php if ($product['StockQuantity'] > 0): ?>
                    <form action="cart.php" method="POST" style="display: flex; gap: 10px; margin-top: 15px;">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="product_id" value="<?php echo $product['ProductID']; ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['StockQuantity']; ?>" 
                               class="quantity-input">
                        <button type="submit" class="btn btn-success" style="flex: 1;">🛒 Add to Cart</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-danger btn-block" disabled style="margin-top: 15px;">Out of Stock</button>
                <?php endif; ?>
                
                <a href="product.php?id=<?php echo $product['ProductID']; ?>" class="btn btn-primary btn-block" style="margin-top: 10px;">
                    View Details
                </a>
            </div>
        </div>
        <?php 
            endwhile;
        else:
        ?>
        <div class="empty-cart" style="grid-column: 1/-1;">
            <h2>No products found 😢</h2>
            <p>Check back later for new products!</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>