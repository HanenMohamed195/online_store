<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once __DIR__ . '/../config/database.php';
// Count cart items
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🛒 Online Store</title>
    <link rel="stylesheet" href="/OnlineStore/css/style.css">
</head>
<body>
    <header class="header">
        <div class="header-container">
            <a href="/OnlineStore/index.php" class="logo">🛒 Online Store</a>
            <ul class="nav-links">
                <li><a href="/OnlineStore/index.php">🏠 Home</a></li>
                <?php if (isset($_SESSION['customer_id'])): ?>
                    <li><a href="/OnlineStore/my_orders.php">📦 My Orders</a></li>
                    <li><a href="/OnlineStore/logout.php">🚪 Logout (<?php echo htmlspecialchars($_SESSION['customer_name']); ?>)</a></li>
                <?php else: ?>
                    <li><a href="/OnlineStore/login.php">🔑 Login</a></li>
                    <li><a href="/OnlineStore/register.php">📝 Register</a></li>
                <?php endif; ?>
                <li><a href="/OnlineStore/cart.php" class="cart-icon">🛒 Cart (<?php echo $cart_count; ?>)</a></li>
                <li><a href="/OnlineStore/admin/" style="background: rgba(255,255,255,0.2);">🔧 Admin</a></li>
            </ul>
        </div>
    </header>
    <main>