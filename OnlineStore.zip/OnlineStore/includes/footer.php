    </main>
    <footer class="footer">
        <p>&copy; 2024 Online Store. All rights reserved.</p>
        <p>📚 Database Project - Built with PHP & MySQL</p>
        <p>Made with ❤️ for Database Course</p>
    </footer>
</body>
</html>