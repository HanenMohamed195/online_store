<?php 
include 'includes/header.php';

// Redirect if cart is empty
if (empty($_SESSION['cart'])) {
    $_SESSION['message'] = "Your cart is empty!";
    header("Location: cart.php");
    exit();
}

// Check if logged in
if (!isset($_SESSION['customer_id'])) {
    $_SESSION['message'] = "Please login to checkout!";
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';
$order_id = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_id = $_SESSION['customer_id'];
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    
    // Calculate total
    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    
    // Create Order
    $date = date('Y-m-d');
    $sql = "INSERT INTO Orders (CustomerID, Date, Status) VALUES ($customer_id, '$date', 'Pending')";
    
    if (mysqli_query($conn, $sql)) {
        $order_id = mysqli_insert_id($conn);
        
        // Insert Order Items
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $qty = $item['quantity'];
            $price = $item['price'];
            
            $sql = "INSERT INTO OrderItem (OrderID, ProductID, Quantity, Price) 
                    VALUES ($order_id, $product_id, $qty, $price)";
            mysqli_query($conn, $sql);
            
            // Update stock
            $sql = "UPDATE Product SET StockQuantity = StockQuantity - $qty WHERE ProductID = $product_id";
            mysqli_query($conn, $sql);
        }
        
        // Insert Payment
        $sql = "INSERT INTO Payment (OrderID, Amount, Date, PaymentMethod) 
                VALUES ($order_id, $total, '$date', '$payment_method')";
        mysqli_query($conn, $sql);
        
        // Clear cart
        $_SESSION['cart'] = [];
        
        $success = true;
    } else {
        $error = "Failed to place order. Please try again.";
    }
}
?>

<div class="container">
    <h1 class="page-title">✅ Checkout</h1>
    
    <?php if ($success): ?>
        <!-- Order Success -->
        <div style="background: white; padding: 50px; border-radius: 15px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            <div style="font-size: 80px; margin-bottom: 20px;">🎉</div>
            <h2 style="color: #28a745; margin-bottom: 20px;">Order Placed Successfully!</h2>
            <p style="font-size: 24px; margin-bottom: 10px;">Order #<?php echo $order_id; ?></p>
            <p style="color: #666; margin-bottom: 30px;">Thank you for your purchase! We'll process your order soon.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="my_orders.php" class="btn btn-primary" style="font-size: 18px;">📦 View My Orders</a>
                <a href="index.php" class="btn btn-success" style="font-size: 18px;">🛍️ Continue Shopping</a>
            </div>
        </div>
    <?php else: ?>
    
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="checkout-grid">
            <!-- Order Summary -->
            <div class="checkout-box">
                <h2 style="margin-bottom: 20px;">📋 Order Summary</h2>
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total = 0;
                        foreach ($_SESSION['cart'] as $product_id => $item): 
                            $subtotal = $item['price'] * $item['quantity'];
                            $total += $subtotal;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td>$<?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><strong>$<?php echo number_format($subtotal, 2); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                            <td><strong style="font-size: 24px; color: #667eea;">$<?php echo number_format($total, 2); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <!-- Payment Form -->
            <div class="checkout-box">
                <h2 style="margin-bottom: 20px;">💳 Payment Details</h2>
                
                <div class="alert alert-info">
                    <strong>👤 Customer:</strong> <?php echo htmlspecialchars($_SESSION['customer_name']); ?><br>
                    <strong>📧 Email:</strong> <?php echo htmlspecialchars($_SESSION['customer_email']); ?>
                </div>
                
                <?php
                $sql = "SELECT Address, Phone FROM Customer WHERE CustomerID = " . $_SESSION['customer_id'];
                $result = mysqli_query($conn, $sql);
                $customer = mysqli_fetch_assoc($result);
                ?>
                
                <div class="alert alert-info">
                    <strong>📍 Shipping Address:</strong><br>
                    <?php echo htmlspecialchars($customer['Address']); ?><br>
                    <strong>📞 Phone:</strong> <?php echo htmlspecialchars($customer['Phone']); ?>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label>💳 Payment Method</label>
                        <select name="payment_method" required>
                            <option value="Credit Card">💳 Credit Card</option>
                            <option value="PayPal">🅿️ PayPal</option>
                            <option value="Cash">💵 Cash on Delivery</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-success btn-block" style="font-size: 20px; padding: 15px;">
                        ✅ Place Order - $<?php echo number_format($total, 2); ?>
                    </button>
                </form>
                
                <a href="cart.php" class="btn btn-primary btn-block" style="margin-top: 15px;">
                    ← Back to Cart
                </a>
            </div>
        </div>
        
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>