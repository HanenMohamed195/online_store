<?php 
include 'includes/header.php';

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add to cart
    if ($action === 'add') {
        $product_id = (int)$_POST['product_id'];
        $quantity = (int)$_POST['quantity'];
        
        if ($quantity < 1) $quantity = 1;
        
        // Get product info
        $sql = "SELECT * FROM Product WHERE ProductID = $product_id";
        $result = mysqli_query($conn, $sql);
        $product = mysqli_fetch_assoc($result);
        
        if ($product) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity'] += $quantity;
            } else {
                $_SESSION['cart'][$product_id] = [
                    'name' => $product['Name'],
                    'price' => $product['Price'],
                    'quantity' => $quantity
                ];
            }
            $_SESSION['message'] = "✅ " . $product['Name'] . " added to cart!";
        }
    }
    
    // Update quantity
    if ($action === 'update') {
        $product_id = (int)$_POST['product_id'];
        $quantity = (int)$_POST['quantity'];
        
        if ($quantity > 0) {
            $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            $_SESSION['message'] = "Cart updated!";
        } else {
            unset($_SESSION['cart'][$product_id]);
            $_SESSION['message'] = "Item removed from cart!";
        }
    }
    
    // Remove item
    if ($action === 'remove') {
        $product_id = (int)$_POST['product_id'];
        unset($_SESSION['cart'][$product_id]);
        $_SESSION['message'] = "Item removed from cart!";
    }
    
    // Clear cart
    if ($action === 'clear') {
        $_SESSION['cart'] = [];
        $_SESSION['message'] = "Cart cleared!";
    }
}
?>

<div class="container">
    <h1 class="page-title">🛒 Your Shopping Cart</h1>
    
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?php 
            echo $_SESSION['message']; 
            unset($_SESSION['message']);
            ?>
        </div>
    <?php endif; ?>
    
    <?php if (empty($_SESSION['cart'])): ?>
        <div class="empty-cart">
            <h2>Your cart is empty! 😢</h2>
            <p>Add some products to your cart and come back!</p>
            <a href="index.php" class="btn btn-primary" style="margin-top: 20px; font-size: 18px;">
                🛍️ Start Shopping
            </a>
        </div>
    <?php else: ?>
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $total = 0;
                foreach ($_SESSION['cart'] as $product_id => $item): 
                    $subtotal = $item['price'] * $item['quantity'];
                    $total += $subtotal;
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                    </td>
                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                    <td>
                        <form action="cart.php" method="POST" style="display: flex; gap: 5px; align-items: center;">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                   min="1" class="quantity-input">
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </form>
                    </td>
                    <td>
                        <strong style="color: #667eea;">$<?php echo number_format($subtotal, 2); ?></strong>
                    </td>
                    <td>
                        <form action="cart.php" method="POST">
                            <input type="hidden" name="action" value="remove">
                            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">🗑️ Remove</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="cart-summary">
            <div class="cart-total">
                Total: $<?php echo number_format($total, 2); ?>
            </div>
            <div style="display: flex; gap: 15px; justify-content: flex-end; flex-wrap: wrap;">
                <form action="cart.php" method="POST">
                    <input type="hidden" name="action" value="clear">
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to clear the cart?');">
                        🗑️ Clear Cart
                    </button>
                </form>
                <a href="index.php" class="btn btn-primary">🛍️ Continue Shopping</a>
                <a href="checkout.php" class="btn btn-success" style="font-size: 18px;">
                    ✅ Proceed to Checkout
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>