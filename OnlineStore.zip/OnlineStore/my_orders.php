<?php 
include 'includes/header.php';

// Check if logged in
if (!isset($_SESSION['customer_id'])) {
    $_SESSION['message'] = "Please login to view your orders!";
    header("Location: login.php");
    exit();
}

$customer_id = $_SESSION['customer_id'];
?>

<div class="container">
    <h1 class="page-title">📦 My Orders</h1>
    
    <?php
    $sql = "SELECT o.*, p.Amount, p.PaymentMethod, p.Date as PaymentDate
            FROM Orders o 
            LEFT JOIN Payment p ON o.OrderID = p.OrderID 
            WHERE o.CustomerID = $customer_id 
            ORDER BY o.OrderID DESC";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) === 0):
    ?>
        <div class="empty-cart">
            <h2>No orders yet! 📭</h2>
            <p>You haven't placed any orders yet.</p>
            <a href="index.php" class="btn btn-primary" style="margin-top: 20px; font-size: 18px;">
                🛍️ Start Shopping
            </a>
        </div>
    <?php else: ?>
        
        <?php while ($order = mysqli_fetch_assoc($result)): ?>
        <div style="background: white; border-radius: 15px; margin-bottom: 20px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            <!-- Order Header -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h3 style="margin: 0;">Order #<?php echo $order['OrderID']; ?></h3>
                    <small>Placed on <?php echo $order['Date']; ?></small>
                </div>
                <div style="text-align: right;">
                    <span class="status status-<?php echo strtolower($order['Status']); ?>" style="font-size: 16px;">
                        <?php echo $order['Status']; ?>
                    </span>
                </div>
            </div>
            
            <!-- Order Items -->
            <div style="padding: 20px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 2px solid #eee;">
                            <th style="text-align: left; padding: 10px 0;">Product</th>
                            <th style="text-align: center; padding: 10px 0;">Quantity</th>
                            <th style="text-align: right; padding: 10px 0;">Price</th>
                            <th style="text-align: right; padding: 10px 0;">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $items_sql = "SELECT oi.*, p.Name as ProductName 
                                      FROM OrderItem oi 
                                      JOIN Product p ON oi.ProductID = p.ProductID 
                                      WHERE oi.OrderID = " . $order['OrderID'];
                        $items_result = mysqli_query($conn, $items_sql);
                        
                        while ($item = mysqli_fetch_assoc($items_result)):
                            $subtotal = $item['Quantity'] * $item['Price'];
                        ?>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 15px 0;"><?php echo htmlspecialchars($item['ProductName']); ?></td>
                            <td style="text-align: center; padding: 15px 0;"><?php echo $item['Quantity']; ?></td>
                            <td style="text-align: right; padding: 15px 0;">$<?php echo number_format($item['Price'], 2); ?></td>
                            <td style="text-align: right; padding: 15px 0;"><strong>$<?php echo number_format($subtotal, 2); ?></strong></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                
                <!-- Order Summary -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px; padding-top: 20px; border-top: 2px solid #eee; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <strong>Payment Method:</strong> <?php echo $order['PaymentMethod'] ?? 'N/A'; ?>
                    </div>
                    <div style="font-size: 24px; color: #667eea;">
                        <strong>Total: $<?php echo number_format($order['Amount'] ?? 0, 2); ?></strong>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
        
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>