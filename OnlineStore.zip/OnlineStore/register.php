<?php 
include 'includes/header.php';

// Redirect if already logged in
if (isset($_SESSION['customer_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    
    // Validation
    if (empty($name) || empty($email) || empty($password) || empty($phone) || empty($address)) {
        $error = "All fields are required!";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 4) {
        $error = "Password must be at least 4 characters!";
    } else {
        // Check if email exists
        $check = mysqli_query($conn, "SELECT * FROM Customer WHERE Email = '$email'");
        if (mysqli_num_rows($check) > 0) {
            $error = "Email already registered!";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO Customer (Name, Email, Password, Phone, Address) 
                    VALUES ('$name', '$email', '$hashed_password', '$phone', '$address')";
            
            if (mysqli_query($conn, $sql)) {
                $success = "Registration successful! 🎉";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<div class="container">
    <div class="form-container">
        <h1 style="text-align: center; margin-bottom: 30px;">📝 Create Account</h1>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <?php echo $success; ?><br>
                <a href="login.php" style="color: #155724; font-weight: bold;">Click here to login</a>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>👤 Full Name</label>
                <input type="text" name="name" required placeholder="Enter your full name" 
                       value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>📧 Email</label>
                <input type="email" name="email" required placeholder="Enter your email"
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>🔒 Password</label>
                <input type="password" name="password" required placeholder="Create a password (min 4 characters)">
            </div>
            
            <div class="form-group">
                <label>🔒 Confirm Password</label>
                <input type="password" name="confirm_password" required placeholder="Confirm your password">
            </div>
            
            <div class="form-group">
                <label>📞 Phone</label>
                <input type="text" name="phone" required placeholder="Enter your phone number"
                       value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label>📍 Address</label>
                <textarea name="address" required placeholder="Enter your full address" rows="3"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-success btn-block" style="font-size: 18px;">
                📝 Create Account
            </button>
        </form>
        
        <p style="text-align: center; margin-top: 20px;">
            Already have an account? <a href="login.php" style="color: #667eea; font-weight: bold;">Login here</a>
        </p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>