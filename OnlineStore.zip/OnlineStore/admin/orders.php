<?php 
session_start();
require_once '../config/database.php';

// Handle Order Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $order_id = (int)$_POST['order_id'];
        $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);
        
        $sql = "UPDATE Orders SET Status = '$new_status' WHERE OrderID = $order_id";
        if (mysqli_query($conn, $sql)) {
            $success = "Order status updated successfully!";
        } else {
            $error = "Failed to update order status.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🛒 Orders - Admin</title>
    <link rel="stylesheet" href="/OnlineStore/css/style.css">
</head>
<body>
    <nav class="admin-nav">
        <a href="/OnlineStore/admin/index.php"><strong>🔧 Admin Panel</strong></a>
        <a href="/OnlineStore/admin/customers.php">👥 Customers</a>
        <a href="/OnlineStore/admin/products.php">📦 Products</a>
        <a href="/OnlineStore/admin/orders.php">🛒 Orders</a>
        <a href="/OnlineStore/index.php" class="back-link">← Back to Store</a>
    </nav>
    
    <div class="container">
        <h1 class="page-title">🛒 All Orders</h1>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <!-- Order Statistics -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px;">
            <?php
            $statuses = ['Pending', 'Shipped', 'Completed', 'Cancelled'];
            $colors = ['#ffc107', '#17a2b8', '#28a745', '#dc3545'];
            
            foreach ($statuses as $index => $status):
                $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM Orders WHERE Status = '$status'");
                $count = mysqli_fetch_assoc($result)['count'];
            ?>
            <div style="background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border-top: 4px solid <?php echo $colors[$index]; ?>;">
                <h3 style="color: <?php echo $colors[$index]; ?>;"><?php echo $count; ?></h3>
                <p><?php echo $status; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Orders Table -->
        <table class="data-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT o.*, c.Name as CustomerName, c.Email, c.Phone,
                               p.Amount, p.PaymentMethod
                        FROM Orders o
                        JOIN Customer c ON o.CustomerID = c.CustomerID
                        LEFT JOIN Payment p ON o.OrderID = p.OrderID
                        ORDER BY o.OrderID DESC";
                $result = mysqli_query($conn, $sql);
                
                if (mysqli_num_rows($result) > 0):
                    while ($row = mysqli_fetch_assoc($result)):
                ?>
                <tr>
                    <td><strong>#<?php echo $row['OrderID']; ?></strong></td>
                    <td>
                        <?php echo htmlspecialchars($row['CustomerName']); ?><br>
                        <small style="color: #888;"><?php echo htmlspecialchars($row['Email']); ?></small>
                    </td>
                    <td><?php echo $row['Date']; ?></td>
                    <td>
                        <?php
                        $items_sql = "SELECT p.Name, oi.Quantity 
                                      FROM OrderItem oi 
                                      JOIN Product p ON oi.ProductID = p.ProductID 
                                      WHERE oi.OrderID = " . $row['OrderID'];
                        $items_result = mysqli_query($conn, $items_sql);
                        while ($item = mysqli_fetch_assoc($items_result)):
                        ?>
                            <small>• <?php echo htmlspecialchars($item['Name']); ?> (x<?php echo $item['Quantity']; ?>)</small><br>
                        <?php endwhile; ?>
                    </td>
                    <td><strong>$<?php echo number_format($row['Amount'] ?? 0, 2); ?></strong></td>
                    <td><?php echo $row['PaymentMethod'] ?? 'N/A'; ?></td>
                    <td>
                        <span class="status status-<?php echo strtolower($row['Status']); ?>">
                            <?php echo $row['Status']; ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" style="display: flex; gap: 5px;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="order_id" value="<?php echo $row['OrderID']; ?>">
                            <select name="new_status" style="padding: 5px; border-radius: 5px; border: 1px solid #ddd;">
                                <option value="Pending" <?php echo $row['Status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="Shipped" <?php echo $row['Status'] === 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                                <option value="Completed" <?php echo $row['Status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="Cancelled" <?php echo $row['Status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </form>
                    </td>
                </tr>
                <?php 
                    endwhile;
                else:
                ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 30px;">
                        No orders found. 📭
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <footer class="footer">
        <p>🔧 Admin Panel - Online Store Database Project</p>
    </footer>
</body>
</html>