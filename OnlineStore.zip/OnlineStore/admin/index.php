<?php 
session_start();
require_once '../config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔧 Admin Dashboard</title>
    <link rel="stylesheet" href="/OnlineStore/css/style.css">
</head>
<body>
    <nav class="admin-nav">
        <a href="/OnlineStore/admin/index.php"><strong>🔧 Admin Panel</strong></a>
        <a href="/OnlineStore/admin/customers.php">👥 Customers</a>
        <a href="/OnlineStore/admin/products.php">📦 Products</a>
        <a href="/OnlineStore/admin/orders.php">🛒 Orders</a>
        <a href="/OnlineStore/index.php" class="back-link">← Back to Store</a>
    </nav>
    
    <div class="container">
        <h1 class="page-title">🔧 Admin Dashboard</h1>
        
        <div class="products-grid">
            <!-- Customers Card -->
            <div class="product-card">
                <div class="product-image" style="background: linear-gradient(135deg, #28a745, #20c997);">
                    👥
                </div>
                <div class="product-info">
                    <h3 class="product-name">Customers</h3>
                    <p class="product-category">Total registered customers</p>
                    <?php
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM Customer");
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <p class="product-price"><?php echo $row['count']; ?></p>
                    <a href="customers.php" class="btn btn-primary btn-block">View All Customers</a>
                </div>
            </div>
            
            <!-- Products Card -->
            <div class="product-card">
                <div class="product-image" style="background: linear-gradient(135deg, #17a2b8, #6f42c1);">
                    📦
                </div>
                <div class="product-info">
                    <h3 class="product-name">Products</h3>
                    <p class="product-category">Total products in store</p>
                    <?php
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM Product");
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <p class="product-price"><?php echo $row['count']; ?></p>
                    <a href="products.php" class="btn btn-primary btn-block">View All Products</a>
                </div>
            </div>
            
            <!-- Orders Card -->
            <div class="product-card">
                <div class="product-image" style="background: linear-gradient(135deg, #ffc107, #fd7e14);">
                    🛒
                </div>
                <div class="product-info">
                    <h3 class="product-name">Orders</h3>
                    <p class="product-category">Total orders placed</p>
                    <?php
                    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM Orders");
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <p class="product-price"><?php echo $row['count']; ?></p>
                    <a href="orders.php" class="btn btn-primary btn-block">View All Orders</a>
                </div>
            </div>
            
            <!-- Revenue Card -->
            <div class="product-card">
                <div class="product-image" style="background: linear-gradient(135deg, #dc3545, #e83e8c);">
                    💰
                </div>
                <div class="product-info">
                    <h3 class="product-name">Total Revenue</h3>
                    <p class="product-category">Total payments received</p>
                    <?php
                    $result = mysqli_query($conn, "SELECT SUM(Amount) as total FROM Payment");
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <p class="product-price">$<?php echo number_format($row['total'] ?? 0, 2); ?></p>
                    <a href="orders.php" class="btn btn-primary btn-block">View Details</a>
                </div>
            </div>
        </div>
        
        <!-- Quick Stats -->
        <h2 style="margin: 40px 0 20px;">📊 Quick Statistics</h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
            <!-- Recent Orders -->
            <div style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                <h3 style="margin-bottom: 15px;">🕐 Recent Orders</h3>
                <?php
                $result = mysqli_query($conn, "SELECT o.OrderID, o.Date, o.Status, c.Name 
                                               FROM Orders o 
                                               JOIN Customer c ON o.CustomerID = c.CustomerID 
                                               ORDER BY o.OrderID DESC LIMIT 5");
                if (mysqli_num_rows($result) > 0):
                    while ($row = mysqli_fetch_assoc($result)):
                ?>
                <div style="padding: 10px 0; border-bottom: 1px solid #eee;">
                    <strong>Order #<?php echo $row['OrderID']; ?></strong> - <?php echo htmlspecialchars($row['Name']); ?><br>
                    <small style="color: #888;"><?php echo $row['Date']; ?> | 
                        <span class="status status-<?php echo strtolower($row['Status']); ?>"><?php echo $row['Status']; ?></span>
                    </small>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <p style="color: #888;">No orders yet</p>
                <?php endif; ?>
            </div>
            
            <!-- Low Stock Products -->
            <div style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                <h3 style="margin-bottom: 15px;">⚠️ Low Stock Products</h3>
                <?php
                $result = mysqli_query($conn, "SELECT Name, StockQuantity FROM Product WHERE StockQuantity < 100 ORDER BY StockQuantity ASC LIMIT 5");
                if (mysqli_num_rows($result) > 0):
                    while ($row = mysqli_fetch_assoc($result)):
                ?>
                <div style="padding: 10px 0; border-bottom: 1px solid #eee; display: flex; justify-content: space-between;">
                    <span><?php echo htmlspecialchars($row['Name']); ?></span>
                    <span style="color: #dc3545; font-weight: bold;"><?php echo $row['StockQuantity']; ?> left</span>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <p style="color: #28a745;">All products are well stocked! ✅</p>
                <?php endif; ?>
            </div>
            
            <!-- Categories -->
            <div style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                <h3 style="margin-bottom: 15px;">📁 Categories</h3>
                <?php
                $result = mysqli_query($conn, "SELECT c.Name, COUNT(p.ProductID) as ProductCount 
                                               FROM Category c 
                                               LEFT JOIN Product p ON c.CategoryID = p.CategoryID 
                                               GROUP BY c.CategoryID");
                while ($row = mysqli_fetch_assoc($result)):
                ?>
                <div style="padding: 10px 0; border-bottom: 1px solid #eee; display: flex; justify-content: space-between;">
                    <span><?php echo htmlspecialchars($row['Name']); ?></span>
                    <span style="color: #667eea; font-weight: bold;"><?php echo $row['ProductCount']; ?> products</span>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <p>🔧 Admin Panel - Online Store Database Project</p>
    </footer>
</body>
</html>