<?php 
session_start();
require_once '../config/database.php';

// Handle Add Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $category_id = (int)$_POST['category_id'];
        
        $sql = "INSERT INTO Product (Name, Description, Price, StockQuantity, CategoryID) 
                VALUES ('$name', '$description', $price, $stock, $category_id)";
        
        if (mysqli_query($conn, $sql)) {
            $success = "Product added successfully!";
        } else {
            $error = "Failed to add product.";
        }
    }
    
    if ($_POST['action'] === 'delete') {
        $product_id = (int)$_POST['product_id'];
        $sql = "DELETE FROM Product WHERE ProductID = $product_id";
        if (mysqli_query($conn, $sql)) {
            $success = "Product deleted successfully!";
        } else {
            $error = "Cannot delete product. It may be in orders.";
        }
    }
    
    if ($_POST['action'] === 'update_stock') {
        $product_id = (int)$_POST['product_id'];
        $new_stock = (int)$_POST['new_stock'];
        $sql = "UPDATE Product SET StockQuantity = $new_stock WHERE ProductID = $product_id";
        if (mysqli_query($conn, $sql)) {
            $success = "Stock updated successfully!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📦 Products - Admin</title>
    <link rel="stylesheet" href="/OnlineStore/css/style.css">
</head>
<body>
    <nav class="admin-nav">
        <a href="/OnlineStore/admin/index.php"><strong>🔧 Admin Panel</strong></a>
        <a href="/OnlineStore/admin/customers.php">👥 Customers</a>
        <a href="/OnlineStore/admin/products.php">📦 Products</a>
        <a href="/OnlineStore/admin/orders.php">🛒 Orders</a>
        <a href="/OnlineStore/index.php" class="back-link">← Back to Store</a>
    </nav>
    
    <div class="container">
        <h1 class="page-title">📦 All Products</h1>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <!-- Add Product Form -->
        <div style="background: white; padding: 25px; border-radius: 15px; margin-bottom: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            <h3 style="margin-bottom: 20px;">➕ Add New Product</h3>
            <form method="POST" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Product Name</label>
                    <input type="text" name="name" required placeholder="Product name">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Description</label>
                    <input type="text" name="description" required placeholder="Description">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Price ($)</label>
                    <input type="number" name="price" step="0.01" required placeholder="0.00">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Stock Quantity</label>
                    <input type="number" name="stock" required placeholder="0">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Category</label>
                    <select name="category_id" required>
                        <?php
                        $cat_result = mysqli_query($conn, "SELECT * FROM Category");
                        while ($cat = mysqli_fetch_assoc($cat_result)):
                        ?>
                        <option value="<?php echo $cat['CategoryID']; ?>"><?php echo htmlspecialchars($cat['Name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-success">➕ Add Product</button>
            </form>
        </div>
        
        <!-- Products Table -->
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT p.*, c.Name as CategoryName 
                        FROM Product p 
                        JOIN Category c ON p.CategoryID = c.CategoryID 
                        ORDER BY p.ProductID DESC";
                $result = mysqli_query($conn, $sql);
                
                while ($row = mysqli_fetch_assoc($result)):
                    $stock_class = $row['StockQuantity'] < 50 ? 'status-pending' : 'status-completed';
                ?>
                <tr>
                    <td><strong>#<?php echo $row['ProductID']; ?></strong></td>
                    <td><?php echo htmlspecialchars($row['Name']); ?></td>
                    <td><?php echo htmlspecialchars(substr($row['Description'], 0, 50)) . '...'; ?></td>
                    <td><strong>$<?php echo number_format($row['Price'], 2); ?></strong></td>
                    <td>
                        <form method="POST" style="display: flex; gap: 5px;">
                            <input type="hidden" name="action" value="update_stock">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <input type="number" name="new_stock" value="<?php echo $row['StockQuantity']; ?>" 
                                   style="width: 70px; padding: 5px; border: 1px solid #ddd; border-radius: 5px;">
                            <button type="submit" class="btn btn-info btn-sm">Update</button>
                        </form>
                    </td>
                    <td>
                        <span class="status status-shipped"><?php echo htmlspecialchars($row['CategoryName']); ?></span>
                    </td>
                    <td>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">🗑️ Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <footer class="footer">
        <p>🔧 Admin Panel - Online Store Database Project</p>
    </footer>
</body>
</html>