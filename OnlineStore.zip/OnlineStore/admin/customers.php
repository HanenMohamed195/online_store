<?php 
session_start();
require_once '../config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👥 Customers - Admin</title>
    <link rel="stylesheet" href="/OnlineStore/css/style.css">
</head>
<body>
    <nav class="admin-nav">
        <a href="/OnlineStore/admin/index.php"><strong>🔧 Admin Panel</strong></a>
        <a href="/OnlineStore/admin/customers.php">👥 Customers</a>
        <a href="/OnlineStore/admin/products.php">📦 Products</a>
        <a href="/OnlineStore/admin/orders.php">🛒 Orders</a>
        <a href="/OnlineStore/index.php" class="back-link">← Back to Store</a>
    </nav>
    
    <div class="container">
        <h1 class="page-title">👥 All Customers</h1>
        
        <!-- Customer Count -->
        <?php
        $count_result = mysqli_query($conn, "SELECT COUNT(*) as total FROM Customer");
        $count = mysqli_fetch_assoc($count_result);
        ?>
        <div class="alert alert-info">
            Total Customers: <strong><?php echo $count['total']; ?></strong>
        </div>
        
        <!-- Customers Table -->
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Total Orders</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT c.*, COUNT(o.OrderID) as OrderCount 
                        FROM Customer c 
                        LEFT JOIN Orders o ON c.CustomerID = o.CustomerID 
                        GROUP BY c.CustomerID 
                        ORDER BY c.CustomerID DESC";
                $result = mysqli_query($conn, $sql);
                
                if (mysqli_num_rows($result) > 0):
                    while ($row = mysqli_fetch_assoc($result)):
                ?>
                <tr>
                    <td><strong>#<?php echo $row['CustomerID']; ?></strong></td>
                    <td><?php echo htmlspecialchars($row['Name']); ?></td>
                    <td><?php echo htmlspecialchars($row['Email']); ?></td>
                    <td><?php echo htmlspecialchars($row['Phone']); ?></td>
                    <td><?php echo htmlspecialchars($row['Address']); ?></td>
                    <td>
                        <span class="status status-<?php echo $row['OrderCount'] > 0 ? 'completed' : 'pending'; ?>">
                            <?php echo $row['OrderCount']; ?> orders
                        </span>
                    </td>
                </tr>
                <?php 
                    endwhile;
                else:
                ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 30px;">
                        No customers found. 😢
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <footer class="footer">
        <p>🔧 Admin Panel - Online Store Database Project</p>
    </footer>
</body>
</html>