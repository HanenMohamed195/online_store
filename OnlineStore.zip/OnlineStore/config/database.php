<?php
// Database Configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "OnlineStore";

// Create connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Start session for cart and login
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set charset
mysqli_set_charset($conn, "utf8");
?>