<?php 
include 'includes/header.php';

// Redirect if already logged in
if (isset($_SESSION['customer_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM Customer WHERE Email = '$email'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) === 1) {
        $customer = mysqli_fetch_assoc($result);
        
        // Check password (supports both hashed and plain text for testing)
        if (password_verify($password, $customer['Password']) || $password === $customer['Password']) {
            $_SESSION['customer_id'] = $customer['CustomerID'];
            $_SESSION['customer_name'] = $customer['Name'];
            $_SESSION['customer_email'] = $customer['Email'];
            
            $_SESSION['message'] = "Welcome back, " . $customer['Name'] . "! 👋";
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "Email not found!";
    }
}
?>

<div class="container">
    <div class="form-container">
        <h1 style="text-align: center; margin-bottom: 30px;">🔑 Login</h1>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-info">
                <?php 
                echo $_SESSION['message']; 
                unset($_SESSION['message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>📧 Email</label>
                <input type="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="form-group">
                <label>🔒 Password</label>
                <input type="password" name="password" required placeholder="Enter your password">
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" style="font-size: 18px;">
                🔑 Login
            </button>
        </form>
        
        <p style="text-align: center; margin-top: 20px;">
            Don't have an account? <a href="register.php" style="color: #667eea; font-weight: bold;">Register here</a>
        </p>
        
        <hr style="margin: 30px 0;">
        
        <div class="alert alert-info">
            <strong>🧪 Test Accounts:</strong><br>
            <small>
                Email: ahmed@email.com | Password: pass123<br>
                Email: sara@email.com | Password: pass456
            </small>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>