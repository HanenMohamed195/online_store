-- Online Store Database Creation Script
-- For XAMPP/phpMyAdmin
-- First, create database manually in phpMyAdmin or uncomment below:
-- CREATE DATABASE IF NOT EXISTS OnlineStore;
USE OnlineStore;

-- Drop tables if they exist (for clean reinstall)
DROP TABLE IF EXISTS CartItem;
DROP TABLE IF EXISTS ShoppingCart;
DROP TABLE IF EXISTS Payment;
DROP TABLE IF EXISTS OrderItem;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Customer;

-- Create Customer Table
CREATE TABLE Customer (
  CustomerID INTEGER NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Email VARCHAR(255) NOT NULL UNIQUE,
  Password VARCHAR(255) NOT NULL,
  Phone VARCHAR(15) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  PRIMARY KEY(CustomerID)
);

-- Create Category Table
CREATE TABLE Category (
  CategoryID INTEGER NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  PRIMARY KEY(CategoryID)
);

-- Create Product Table
CREATE TABLE Product (
  ProductID INTEGER NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Description TEXT NOT NULL,
  Price DECIMAL(10,2) NOT NULL,
  StockQuantity INTEGER NOT NULL,
  CategoryID INTEGER NOT NULL,
  PRIMARY KEY(ProductID),
  FOREIGN KEY(CategoryID) REFERENCES Category(CategoryID)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Create Orders Table
CREATE TABLE Orders (
  OrderID INTEGER NOT NULL AUTO_INCREMENT,
  CustomerID INTEGER NOT NULL,
  Date DATE NOT NULL,
  Status VARCHAR(50) NOT NULL,
  PRIMARY KEY(OrderID),
  FOREIGN KEY(CustomerID) REFERENCES Customer(CustomerID)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Create OrderItem Table
CREATE TABLE OrderItem (
  OrderItemID INTEGER NOT NULL AUTO_INCREMENT,
  OrderID INTEGER NOT NULL,
  ProductID INTEGER NOT NULL,
  Quantity INTEGER NOT NULL,
  Price DECIMAL(10,2) NOT NULL,
  PRIMARY KEY(OrderItemID),
  FOREIGN KEY(OrderID) REFERENCES Orders(OrderID)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY(ProductID) REFERENCES Product(ProductID)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Create Payment Table
CREATE TABLE Payment (
  PaymentID INTEGER NOT NULL AUTO_INCREMENT,
  OrderID INTEGER NOT NULL,
  Amount DECIMAL(10,2) NOT NULL,
  Date DATE NOT NULL,
  PaymentMethod VARCHAR(50) NOT NULL,
  PRIMARY KEY(PaymentID),
  FOREIGN KEY(OrderID) REFERENCES Orders(OrderID)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- Create ShoppingCart Table
CREATE TABLE ShoppingCart (
  CartID INTEGER NOT NULL AUTO_INCREMENT,
  CustomerID INTEGER NOT NULL,
  Date DATE NOT NULL,
  PRIMARY KEY(CartID),
  FOREIGN KEY(CustomerID) REFERENCES Customer(CustomerID)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- Create CartItem Table
CREATE TABLE CartItem (
  CartItemID INTEGER NOT NULL AUTO_INCREMENT,
  CartID INTEGER NOT NULL,
  ProductID INTEGER NOT NULL,
  Quantity INTEGER NOT NULL,
  PRIMARY KEY(CartItemID),
  FOREIGN KEY(CartID) REFERENCES ShoppingCart(CartID)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY(ProductID) REFERENCES Product(ProductID)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Display success message
SELECT 'Database and tables created successfully!' AS Status;