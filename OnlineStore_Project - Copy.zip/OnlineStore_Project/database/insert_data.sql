-- Insert Sample Data (Minimum 2 records per table)

-- Customer Data
INSERT INTO Customer (Name, Email, Password, Phone, Address) VALUES
('Ahmed Hassan', 'ahmed@email.com', 'pass123', '01012345678', '123 Cairo St, Egypt'),
('Sara Mohamed', 'sara@email.com', 'pass456', '01098765432', '456 Alex Ave, Egypt'),
('Omar Ali', 'omar@email.com', 'pass789', '01155554444', '789 Giza Road, Egypt');

-- Category Data
INSERT INTO Category (Name) VALUES
('Electronics'),
('Clothing'),
('Books');

-- Product Data
INSERT INTO Product (Name, Description, Price, StockQuantity, CategoryID) VALUES
('Laptop', 'High-performance laptop 16GB RAM', 15000.00, 50, 1),
('Smartphone', 'Latest model smartphone', 8000.00, 100, 1),
('T-Shirt', 'Cotton casual t-shirt', 200.00, 200, 2),
('Jeans', 'Blue denim jeans', 450.00, 150, 2),
('Python Book', 'Learn Python programming', 350.00, 75, 3),
('Database Book', 'SQL and Database Design', 400.00, 60, 3);

-- Orders Data
INSERT INTO Orders (CustomerID, Date, Status) VALUES
(1, '2024-01-15', 'Completed'),
(2, '2024-01-16', 'Pending'),
(1, '2024-01-17', 'Shipped'),
(3, '2024-01-18', 'Completed');

-- OrderItem Data
INSERT INTO OrderItem (OrderID, ProductID, Quantity, Price) VALUES
(1, 1, 1, 15000.00),
(1, 3, 2, 200.00),
(2, 2, 1, 8000.00),
(3, 5, 3, 350.00),
(4, 4, 2, 450.00);

-- Payment Data
INSERT INTO Payment (OrderID, Amount, Date, PaymentMethod) VALUES
(1, 15400.00, '2024-01-15', 'Credit Card'),
(4, 900.00, '2024-01-18', 'Cash'),
(3, 1050.00, '2024-01-17', 'PayPal');

-- ShoppingCart Data
INSERT INTO ShoppingCart (CustomerID, Date) VALUES
(1, '2024-01-20'),
(2, '2024-01-20'),
(3, '2024-01-21');

-- CartItem Data
INSERT INTO CartItem (CartID, ProductID, Quantity) VALUES
(1, 2, 1),
(1, 6, 2),
(2, 1, 1),
(3, 3, 3);