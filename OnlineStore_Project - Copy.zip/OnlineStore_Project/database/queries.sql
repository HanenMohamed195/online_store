-- Transaction Queries for Online Store Database
USE OnlineStore;

-- Query 1: List all customers
SELECT CustomerID, Name, Email, Phone, Address
FROM Customer;

-- Query 2: List all orders with customer info
SELECT o.OrderID, o.Date AS OrderDate, o.Status,
       c.Name AS CustomerName, c.Email
FROM Orders o
JOIN Customer c ON o.CustomerID = c.CustomerID;

-- Query 3: Display order items for a specific order (OrderID = 1)
SELECT oi.OrderItemID, oi.OrderID,
       p.Name AS ProductName, oi.Quantity, oi.Price
FROM OrderItem oi
JOIN Product p ON oi.ProductID = p.ProductID
WHERE oi.OrderID = 1;

-- Query 4: List all products with category names
SELECT p.ProductID, p.Name, p.Price, p.StockQuantity,
       c.Name AS CategoryName
FROM Product p
JOIN Category c ON p.CategoryID = c.CategoryID;

-- Query 5: Show items in a customer's shopping cart (CustomerID = 1)
SELECT sc.CartID, c.Name AS CustomerName,
       p.Name AS ProductName, ci.Quantity, p.Price
FROM ShoppingCart sc
JOIN Customer c ON sc.CustomerID = c.CustomerID
JOIN CartItem ci ON sc.CartID = ci.CartID
JOIN Product p ON ci.ProductID = p.ProductID
WHERE sc.CustomerID = 1;

-- Query 6: List all payments with order details
SELECT p.PaymentID, p.OrderID, p.Amount, p.Date AS PaymentDate,
       p.PaymentMethod, o.Status
FROM Payment p
JOIN Orders o ON p.OrderID = o.OrderID;

-- Query 7: Calculate total order value for each order
SELECT oi.OrderID,
       SUM(oi.Quantity * oi.Price) AS TotalOrderValue
FROM OrderItem oi
GROUP BY oi.OrderID;

-- BONUS Query 8: Find products with low stock (less than 100 items)
SELECT ProductID, Name, StockQuantity, 
       CASE 
         WHEN StockQuantity < 50 THEN 'Critical'
         WHEN StockQuantity < 100 THEN 'Low'
         ELSE 'Adequate'
       END AS StockStatus
FROM Product
WHERE StockQuantity < 100
ORDER BY StockQuantity ASC;

-- BONUS Query 9: Show customers who have placed orders with total spent
SELECT c.CustomerID, c.Name, c.Email,
       COUNT(DISTINCT o.OrderID) AS TotalOrders,
       COALESCE(SUM(p.Amount), 0) AS TotalSpent
FROM Customer c
LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
LEFT JOIN Payment p ON o.OrderID = p.OrderID
GROUP BY c.CustomerID, c.Name, c.Email
ORDER BY TotalSpent DESC;

-- BONUS Query 10: List products never ordered
SELECT p.ProductID, p.Name, p.Price, p.StockQuantity
FROM Product p
LEFT JOIN OrderItem oi ON p.ProductID = oi.ProductID
WHERE oi.ProductID IS NULL;