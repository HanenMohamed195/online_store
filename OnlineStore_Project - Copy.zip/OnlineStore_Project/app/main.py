import tkinter as tk
from tkinter import ttk, messagebox, font

# Try to import mysql connector, install if not found
try:
    import mysql.connector
except ImportError:
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "mysql-connector-python"])
    import mysql.connector


class OnlineStoreApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🛒 Online Store Database System")
        self.root.geometry("1200x800")
        self.root.configure(bg="#f0f2f5")
        self.conn = None
        
        # Custom fonts
        self.title_font = font.Font(family="Helvetica", size=24, weight="bold")
        self.header_font = font.Font(family="Helvetica", size=12, weight="bold")
        self.normal_font = font.Font(family="Helvetica", size=11)
        
        self.create_widgets()
    
    def create_widgets(self):
        # ==========================================
        # HEADER
        # ==========================================
        header_frame = tk.Frame(self.root, bg="#667eea", height=80)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(
            header_frame, 
            text="🛒 Online Store Database System", 
            font=self.title_font,
            bg="#667eea",
            fg="white"
        )
        title_label.pack(pady=20)
        
        # ==========================================
        # CONNECTION FRAME
        # ==========================================
        conn_frame = tk.LabelFrame(
            self.root, 
            text="📡 Database Connection", 
            font=self.header_font,
            bg="#f0f2f5",
            padx=20,
            pady=15
        )
        conn_frame.pack(fill="x", padx=20, pady=15)
        
        # Connection fields
        fields_frame = tk.Frame(conn_frame, bg="#f0f2f5")
        fields_frame.pack(fill="x")
        
        # Host
        tk.Label(fields_frame, text="Host:", font=self.normal_font, bg="#f0f2f5").grid(row=0, column=0, padx=5, sticky="e")
        self.host_entry = tk.Entry(fields_frame, font=self.normal_font, width=15, relief="solid", bd=1)
        self.host_entry.insert(0, "localhost")
        self.host_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # User
        tk.Label(fields_frame, text="User:", font=self.normal_font, bg="#f0f2f5").grid(row=0, column=2, padx=5, sticky="e")
        self.user_entry = tk.Entry(fields_frame, font=self.normal_font, width=15, relief="solid", bd=1)
        self.user_entry.insert(0, "root")
        self.user_entry.grid(row=0, column=3, padx=5, pady=5)
        
        # Password
        tk.Label(fields_frame, text="Password:", font=self.normal_font, bg="#f0f2f5").grid(row=0, column=4, padx=5, sticky="e")
        self.pass_entry = tk.Entry(fields_frame, font=self.normal_font, width=15, show="*", relief="solid", bd=1)
        self.pass_entry.grid(row=0, column=5, padx=5, pady=5)
        
        # Database
        tk.Label(fields_frame, text="Database:", font=self.normal_font, bg="#f0f2f5").grid(row=0, column=6, padx=5, sticky="e")
        self.db_entry = tk.Entry(fields_frame, font=self.normal_font, width=15, relief="solid", bd=1)
        self.db_entry.insert(0, "OnlineStore")
        self.db_entry.grid(row=0, column=7, padx=5, pady=5)
        
        # Connect Button
        self.connect_btn = tk.Button(
            fields_frame, 
            text="🔌 Connect", 
            font=self.header_font,
            bg="#28a745",
            fg="white",
            padx=20,
            pady=5,
            relief="flat",
            cursor="hand2",
            command=self.connect_db
        )
        self.connect_btn.grid(row=0, column=8, padx=15)
        
        # Status Label
        self.status_label = tk.Label(
            fields_frame, 
            text="❌ Not Connected", 
            font=self.header_font,
            bg="#f0f2f5",
            fg="#dc3545"
        )
        self.status_label.grid(row=0, column=9, padx=10)
        
        # ==========================================
        # QUERIES FRAME
        # ==========================================
        queries_frame = tk.LabelFrame(
            self.root, 
            text="📊 Run Queries (10 Queries)", 
            font=self.header_font,
            bg="#f0f2f5",
            padx=20,
            pady=15
        )
        queries_frame.pack(fill="x", padx=20, pady=10)
        
        # Query buttons
        queries = [
            ("1. All Customers", 1),
            ("2. Orders + Customer Info", 2),
            ("3. Order Items (ID=1)", 3),
            ("4. Products + Categories", 4),
            ("5. Shopping Cart (ID=1)", 5),
            ("6. Payments + Orders", 6),
            ("7. Total Order Value", 7),
            ("8. Low Stock Products", 8),
            ("9. Customers with Orders", 9),
            ("10. Orders per Customer", 10)
        ]
        
        btn_frame = tk.Frame(queries_frame, bg="#f0f2f5")
        btn_frame.pack(fill="x")
        
        for i, (text, num) in enumerate(queries):
            btn = tk.Button(
                btn_frame, 
                text=text, 
                font=self.normal_font,
                bg="#667eea",
                fg="white",
                width=22,
                pady=8,
                relief="flat",
                cursor="hand2",
                command=lambda n=num: self.run_query(n)
            )
            btn.grid(row=i//5, column=i%5, padx=5, pady=5)
            
            # Hover effects
            btn.bind("<Enter>", lambda e, b=btn: b.configure(bg="#764ba2"))
            btn.bind("<Leave>", lambda e, b=btn: b.configure(bg="#667eea"))
        
        # ==========================================
        # CUSTOM QUERY FRAME
        # ==========================================
        custom_frame = tk.LabelFrame(
            self.root, 
            text="✏️ Custom SQL Query", 
            font=self.header_font,
            bg="#f0f2f5",
            padx=20,
            pady=10
        )
        custom_frame.pack(fill="x", padx=20, pady=10)
        
        custom_inner = tk.Frame(custom_frame, bg="#f0f2f5")
        custom_inner.pack(fill="x")
        
        self.custom_query = tk.Entry(custom_inner, font=self.normal_font, width=80, relief="solid", bd=1)
        self.custom_query.insert(0, "SELECT * FROM Customer")
        self.custom_query.pack(side="left", padx=5, pady=5, ipady=8)
        
        run_custom_btn = tk.Button(
            custom_inner, 
            text="▶ Run Query", 
            font=self.header_font,
            bg="#17a2b8",
            fg="white",
            padx=20,
            pady=5,
            relief="flat",
            cursor="hand2",
            command=self.run_custom_query
        )
        run_custom_btn.pack(side="left", padx=10)
        
        # ==========================================
        # RESULTS FRAME
        # ==========================================
        results_frame = tk.LabelFrame(
            self.root, 
            text="📋 Query Results", 
            font=self.header_font,
            bg="#f0f2f5",
            padx=20,
            pady=15
        )
        results_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Treeview with Scrollbars
        tree_frame = tk.Frame(results_frame)
        tree_frame.pack(fill="both", expand=True)
        
        # Scrollbars
        y_scroll = ttk.Scrollbar(tree_frame, orient="vertical")
        x_scroll = ttk.Scrollbar(tree_frame, orient="horizontal")
        
        # Style for Treeview
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", font=self.normal_font, rowheight=30)
        style.configure("Treeview.Heading", font=self.header_font, background="#667eea", foreground="white")
        style.map("Treeview", background=[("selected", "#667eea")])
        
        self.result_tree = ttk.Treeview(
            tree_frame,
            yscrollcommand=y_scroll.set,
            xscrollcommand=x_scroll.set
        )
        
        y_scroll.config(command=self.result_tree.yview)
        x_scroll.config(command=self.result_tree.xview)
        
        y_scroll.pack(side="right", fill="y")
        x_scroll.pack(side="bottom", fill="x")
        self.result_tree.pack(fill="both", expand=True)
        
        # ==========================================
        # STATUS BAR
        # ==========================================
        self.info_label = tk.Label(
            self.root, 
            text="💡 Ready - Click Connect to start", 
            font=self.normal_font,
            bg="#343a40",
            fg="white",
            anchor="w",
            padx=20,
            pady=10
        )
        self.info_label.pack(fill="x", side="bottom")
    
    def connect_db(self):
        try:
            self.conn = mysql.connector.connect(
                host=self.host_entry.get(),
                user=self.user_entry.get(),
                password=self.pass_entry.get(),
                database=self.db_entry.get()
            )
            self.status_label.config(text="✅ Connected!", fg="#28a745")
            self.info_label.config(text=f"✅ Connected to database: {self.db_entry.get()}")
            self.connect_btn.config(bg="#28a745", text="✓ Connected")
            messagebox.showinfo("Success", f"Connected to {self.db_entry.get()} database!")
        except Exception as e:
            self.status_label.config(text="❌ Failed", fg="#dc3545")
            messagebox.showerror("Connection Error", f"Failed to connect:\n{e}")
    
    def run_query(self, query_num):
        if not self.conn:
            messagebox.showwarning("Warning", "Please connect to database first!")
            return
        
        queries = {
            1: ("All Customers", 
                "SELECT CustomerID, Name, Email, Phone, Address FROM Customer"),
            
            2: ("Orders with Customer Info", 
                """SELECT o.OrderID, o.Date AS OrderDate, o.Status, 
                   c.Name AS CustomerName, c.Email 
                   FROM Orders o 
                   JOIN Customer c ON o.CustomerID = c.CustomerID"""),
            
            3: ("Order Items for Order #1", 
                """SELECT oi.OrderItemID, oi.OrderID, p.Name AS ProductName, 
                   oi.Quantity, oi.Price 
                   FROM OrderItem oi 
                   JOIN Product p ON oi.ProductID = p.ProductID 
                   WHERE oi.OrderID = 1"""),
            
            4: ("Products with Categories", 
                """SELECT p.ProductID, p.Name, p.Price, p.StockQuantity, 
                   c.Name AS CategoryName 
                   FROM Product p 
                   JOIN Category c ON p.CategoryID = c.CategoryID"""),
            
            5: ("Shopping Cart for Customer #1", 
                """SELECT sc.CartID, c.Name AS CustomerName, 
                   p.Name AS ProductName, ci.Quantity, p.Price 
                   FROM ShoppingCart sc 
                   JOIN Customer c ON sc.CustomerID = c.CustomerID 
                   JOIN CartItem ci ON sc.CartID = ci.CartID 
                   JOIN Product p ON ci.ProductID = p.ProductID 
                   WHERE sc.CustomerID = 1"""),
            
            6: ("Payments with Order Details", 
                """SELECT p.PaymentID, p.OrderID, p.Amount, p.Date AS PaymentDate, 
                   p.PaymentMethod, o.Status 
                   FROM Payment p 
                   JOIN Orders o ON p.OrderID = o.OrderID"""),
            
            7: ("Total Order Value", 
                """SELECT oi.OrderID, SUM(oi.Quantity * oi.Price) AS TotalOrderValue 
                   FROM OrderItem oi 
                   GROUP BY oi.OrderID"""),
            
            8: ("Low Stock Products (< 100)", 
                """SELECT ProductID, Name, StockQuantity 
                   FROM Product 
                   WHERE StockQuantity < 100 
                   ORDER BY StockQuantity ASC"""),
            
            9: ("Customers Who Placed Orders", 
                """SELECT DISTINCT c.CustomerID, c.Name, c.Email 
                   FROM Customer c 
                   JOIN Orders o ON c.CustomerID = o.CustomerID"""),
            
            10: ("Order Count per Customer", 
                 """SELECT c.Name, COUNT(o.OrderID) AS TotalOrders 
                    FROM Customer c 
                    LEFT JOIN Orders o ON c.CustomerID = o.CustomerID 
                    GROUP BY c.CustomerID, c.Name""")
        }
        
        query_name, sql = queries[query_num]
        self.execute_query(sql, query_name)
    
    def run_custom_query(self):
        if not self.conn:
            messagebox.showwarning("Warning", "Please connect to database first!")
            return
        
        sql = self.custom_query.get()
        self.execute_query(sql, "Custom Query")
    
    def execute_query(self, sql, query_name):
        try:
            cursor = self.conn.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            
            # Clear previous results
            for item in self.result_tree.get_children():
                self.result_tree.delete(item)
            
            # Configure columns
            self.result_tree["columns"] = columns
            self.result_tree["show"] = "headings"
            
            for col in columns:
                self.result_tree.heading(col, text=col)
                self.result_tree.column(col, width=150, minwidth=100)
            
            # Insert data with alternating colors
            for i, row in enumerate(rows):
                tag = "even" if i % 2 == 0 else "odd"
                self.result_tree.insert("", "end", values=row, tags=(tag,))
            
            # Configure row colors
            self.result_tree.tag_configure("even", background="#f8f9fa")
            self.result_tree.tag_configure("odd", background="#ffffff")
            
            self.info_label.config(
                text=f"✅ {query_name} - Found {len(rows)} records"
            )
            
        except Exception as e:
            messagebox.showerror("Query Error", f"Query failed:\n{e}")
            self.info_label.config(text=f"❌ Query failed: {str(e)[:50]}...")


class TableViewerWindow:
    """Window to view specific table data"""
    def __init__(self, parent, conn, table_name):
        self.window = tk.Toplevel(parent)
        self.window.title(f"📋 {table_name} Table")
        self.window.geometry("800x500")
        self.conn = conn
        self.table_name = table_name
        
        self.create_widgets()
        self.load_data()
    
    def create_widgets(self):
        # Title
        title = tk.Label(
            self.window,
            text=f"📋 {self.table_name} Table",
            font=("Helvetica", 16, "bold"),
            pady=10
        )
        title.pack()
        
        # Treeview
        tree_frame = tk.Frame(self.window)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        y_scroll = ttk.Scrollbar(tree_frame, orient="vertical")
        x_scroll = ttk.Scrollbar(tree_frame, orient="horizontal")
        
        self.tree = ttk.Treeview(
            tree_frame,
            yscrollcommand=y_scroll.set,
            xscrollcommand=x_scroll.set
        )
        
        y_scroll.config(command=self.tree.yview)
        x_scroll.config(command=self.tree.xview)
        
        y_scroll.pack(side="right", fill="y")
        x_scroll.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)
    
    def load_data(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute(f"SELECT * FROM {self.table_name}")
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            
            self.tree["columns"] = columns
            self.tree["show"] = "headings"
            
            for col in columns:
                self.tree.heading(col, text=col)
                self.tree.column(col, width=120)
            
            for row in rows:
                self.tree.insert("", "end", values=row)
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load data:\n{e}")


# ==========================================
# MAIN APPLICATION
# ==========================================
if __name__ == "__main__":
    root = tk.Tk()
    
    # Center window on screen
    window_width = 1200
    window_height = 800
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width // 2) - (window_width // 2)
    y = (screen_height // 2) - (window_height // 2)
    root.geometry(f"{window_width}x{window_height}+{x}+{y}")
    
    app = OnlineStoreApp(root)
    root.mainloop()